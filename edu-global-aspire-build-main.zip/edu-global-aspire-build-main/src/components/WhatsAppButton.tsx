
import { MessageCircle } from "lucide-react";

const WhatsAppButton = () => {
  const phoneNumber = "+60122889037"; // Updated phone number
  const message = "Hello, I'm interested in learning more about EduGlobal Consortium - Soaring in Education. Leading Globally.";
  
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
  
  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-[#25D366] text-white p-3 rounded-full shadow-lg z-50 hover:scale-110 transition-transform"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={30} fill="white" stroke="white" />
    </a>
  );
};

export default WhatsAppButton;
