
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section
      id="home"
      className="pt-28 pb-20 md:pt-32 md:pb-24 bg-gradient-to-r from-[#f8f9ff] to-[#eef1f5]"
    >
      <div className="container-custom mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <p className="text-edu-teal font-medium mb-2">Soaring in Education. Leading Globally.</p>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-edu-blue leading-tight mb-6">
              Empowering Global Leaders Through Education
            </h1>
            <p className="text-edu-gray text-lg md:text-xl mb-8 max-w-lg">
              EduGlobal Consortium provides innovative educational programs under the leadership of Dr. Malathi Alagu, CEO and Head Consultant. We prepare students to excel in an interconnected world.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-edu-blue hover:bg-edu-blue/90" onClick={() => document.getElementById('programs')?.scrollIntoView({ behavior: 'smooth' })}>
                Explore Services <ArrowRight size={16} className="ml-2" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
                Contact Us
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -z-10 w-[300px] h-[300px] bg-edu-teal/10 rounded-full -top-10 -right-10"></div>
            <img
              src="/lovable-uploads/e1138018-225b-4000-803b-a7ec60e66c8e.png"
              alt="EduGlobal Consortium Student"
              className="w-full h-auto rounded-xl shadow-lg hover-scale"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
