
import { useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: "Gajen",
      position: "CEO of GKK ConsultantCrew, Partner & Reviewer",
      quote: "Partnering with EduGlobal Consortium has been an exceptional experience. Dr. Malathi's vision and dedication to creating global educational opportunities is truly inspiring.",
      image: "https://media.licdn.com/dms/image/v2/D5622AQH1IqILcx1ogw/feedshare-shrink_480/feedshare-shrink_480/0/1721902116327?e=1747872000&v=beta&t=qQWPSAhKrFIxE1ypBahFPemJqYok5CpiDxafrjXByFk",
    },
    {
      id: 2,
      name: "Dr. Malathi Alagu",
      position: "Global Women Leadership Achievement",
      quote: "Education is the foundation upon which we build our future. At EduGlobal Consortium, we're committed to empowering individuals through transformative educational experiences.",
      image: "https://media.licdn.com/dms/image/v2/D5622AQGQC6vDn_i8Qw/feedshare-shrink_1280/B56ZWsQ.dEHQAo-/0/1742351887449?e=1749081600&v=beta&t=twlt2bFSoxr10aob-X7R_Uwv6Xip8xG5HJ76aasXgbI",
    },
    {
      id: 3,
      name: "Dr. Malathi Alagu",
      position: "Meeting with Bank Rakyat",
      quote: "Creating partnerships with financial institutions like Bank Rakyat allows us to expand our impact and reach more students across Malaysia and beyond.",
      image: "https://media.licdn.com/dms/image/v2/D5622AQGqDblVxJbuog/feedshare-shrink_2048_1536/B56ZRAdLVUG8Ao-/0/1736248179983?e=1749081600&v=beta&t=HvFMrUF4X1ArLRSeZVSk7wUmJQ1m_Ksshvs3BUmidV8",
    },
  ];

  const [current, setCurrent] = useState(0);

  const next = () => {
    setCurrent((current + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="section-padding bg-white">
      <div className="container-custom mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-edu-blue mb-4">
            Certificate Partners
          </h2>
          <p className="text-edu-gray text-lg max-w-3xl mx-auto">
            Learn about our achievements and partnerships with leading organizations.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="bg-edu-light-gray rounded-2xl p-8 md:p-12 relative">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="w-40 h-40 rounded-full overflow-hidden shrink-0 mx-auto md:mx-0">
                <img
                  src={testimonials[current].image}
                  alt={testimonials[current].name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <svg
                  className="w-12 h-12 text-edu-blue/10 mb-4"
                  fill="currentColor"
                  viewBox="0 0 32 32"
                  aria-hidden="true"
                >
                  <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
                </svg>
                <p className="text-edu-gray text-lg mb-6 italic">
                  "{testimonials[current].quote}"
                </p>
                <h4 className="font-semibold text-xl text-edu-blue">
                  {testimonials[current].name}
                </h4>
                <p className="text-edu-gray">{testimonials[current].position}</p>
              </div>
            </div>
            
            <div className="flex justify-center md:justify-end gap-2 mt-6">
              <Button
                variant="outline"
                size="icon"
                onClick={prev}
                className="rounded-full"
              >
                <ArrowLeft size={18} />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={next}
                className="rounded-full"
              >
                <ArrowRight size={18} />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="bg-edu-light-gray p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className="w-5 h-5 text-edu-orange"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-edu-gray mb-4">
                "Dr. Malathi's global perspective helped our organization develop a more comprehensive understanding of international business."
              </p>
              <p className="font-medium">- Corporate Partner</p>
            </div>
            <div className="bg-edu-light-gray p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className="w-5 h-5 text-edu-orange"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-edu-gray mb-4">
                "The mentorship provided through EduGlobal has been instrumental in our professional development program."
              </p>
              <p className="font-medium">- Training Director</p>
            </div>
            <div className="bg-edu-light-gray p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className="w-5 h-5 text-edu-orange"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-edu-gray mb-4">
                "The customized training solutions delivered by EduGlobal Consortium have significantly improved our team's performance."
              </p>
              <p className="font-medium">- Corporate Client</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
