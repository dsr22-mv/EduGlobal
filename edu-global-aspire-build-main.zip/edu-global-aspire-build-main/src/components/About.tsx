
import { CheckCircle } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="section-padding bg-white">
      <div className="container-custom mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-edu-blue mb-4">
            About EduGlobal Consortium
          </h2>
          <p className="text-edu-gray text-lg max-w-3xl mx-auto">
            We are dedicated to providing innovative educational programs that prepare students to excel in an interconnected world through freedom, leadership, and empowerment.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h3 className="text-2xl font-semibold mb-6 text-edu-blue">
              Our Story
            </h3>
            <p className="text-edu-gray mb-6">
              EduGlobal Consortium was founded by Dr. Malathi Alagu with a vision to foster educational excellence through innovative teaching methods, global perspectives, and leadership development. We believe in empowering students with the knowledge, skills, and mindset needed to thrive in today's interconnected world.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <CheckCircle className="text-edu-teal mt-1 shrink-0" />
                <p>Providing world-class educational experiences that prepare students for global challenges</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-edu-teal mt-1 shrink-0" />
                <p>Building leadership skills through practical experiences and mentorship</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-edu-teal mt-1 shrink-0" />
                <p>Fostering cross-cultural understanding and global citizenship</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-edu-teal mt-1 shrink-0" />
                <p>Creating innovative learning environments that inspire excellence</p>
              </div>
            </div>
          </div>

          <div className="relative order-1 lg:order-2">
            <img
              src="https://www.unitar.my/wp-content/uploads/2024/03/dr.mala_.png"
              alt="Dr. Malathi Alagu"
              className="rounded-lg shadow-lg mx-auto hover-scale"
              style={{ maxWidth: "400px" }}
            />
            <div className="mt-6 text-center">
              <h4 className="text-xl font-medium text-edu-blue">Dr. Malathi Alagu</h4>
              <p className="text-edu-gray">CEO & Head Consultant</p>
            </div>
          </div>
        </div>
        
        <div className="mt-16 p-8 bg-edu-light-gray rounded-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-edu-blue">
                Our Vision
              </h3>
              <p className="text-edu-gray text-lg mb-6">
                To be a global leader in education that transforms students into thoughtful leaders who make positive contributions to society and the world.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-edu-blue">
                Our Mission
              </h3>
              <p className="text-edu-gray text-lg mb-6">
                To provide exceptional educational experiences that develop global competencies, foster leadership skills, and empower individuals to achieve their full potential in an interconnected world.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h4 className="text-xl font-medium text-edu-teal mb-3">Freedom</h4>
              <p className="text-edu-gray">We believe in providing the freedom to explore diverse ideas and approaches to learning and leadership.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h4 className="text-xl font-medium text-edu-teal mb-3">Leadership</h4>
              <p className="text-edu-gray">We develop future leaders who can navigate global challenges with confidence and integrity.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h4 className="text-xl font-medium text-edu-teal mb-3">Empowerment</h4>
              <p className="text-edu-gray">We empower individuals with the knowledge, skills, and mindset needed to create positive change.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
