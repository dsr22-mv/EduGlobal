
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? "bg-white shadow-md py-2"
          : "bg-transparent py-4"
      )}
    >
      <div className="container-custom mx-auto flex items-center justify-between">
        <a href="#" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-edu-blue rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-lg">EG</span>
          </div>
          <div>
            <span className="font-display font-bold text-edu-blue text-xl md:text-2xl">
              EduGlobal Consortium
            </span>
            <p className="text-edu-gray text-xs hidden md:block">Soaring in Education. Leading Globally.</p>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <a
            href="#home"
            className="text-edu-gray hover:text-edu-blue transition-colors font-medium"
          >
            Home
          </a>
          <a
            href="#about"
            className="text-edu-gray hover:text-edu-blue transition-colors font-medium"
          >
            About Us
          </a>
          <a
            href="#programs"
            className="text-edu-gray hover:text-edu-blue transition-colors font-medium"
          >
            Services
          </a>
          <a
            href="#testimonials"
            className="text-edu-gray hover:text-edu-blue transition-colors font-medium"
          >
            Certificate Partners
          </a>
          <Button onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
            Contact Us
          </Button>
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-edu-blue"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Mobile Menu */}
        <div
          className={cn(
            "fixed inset-0 bg-white z-50 flex flex-col pt-20 px-6 transition-transform duration-300 md:hidden",
            isOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          <a
            href="#home"
            className="py-4 text-xl border-b border-gray-100"
            onClick={() => setIsOpen(false)}
          >
            Home
          </a>
          <a
            href="#about"
            className="py-4 text-xl border-b border-gray-100"
            onClick={() => setIsOpen(false)}
          >
            About Us
          </a>
          <a
            href="#programs"
            className="py-4 text-xl border-b border-gray-100"
            onClick={() => setIsOpen(false)}
          >
            Services
          </a>
          <a
            href="#testimonials"
            className="py-4 text-xl border-b border-gray-100"
            onClick={() => setIsOpen(false)}
          >
            Certificate Partners
          </a>
          <Button 
            className="mt-6"
            onClick={() => {
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              setIsOpen(false);
            }}
          >
            Contact Us
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
