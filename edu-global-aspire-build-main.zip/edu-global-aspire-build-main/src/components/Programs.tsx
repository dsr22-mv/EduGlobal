
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Programs = () => {
  const services = [
    {
      title: "Solution Customization",
      description: "Custom learning frameworks designed specifically for working adults' unique needs and organizational contexts.",
      details: [
        "Micro-credential",
        "Professional Certification",
        "International Partner Programmes",
        "Academic Programmes"
      ],
      image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80"
    },
    {
      title: "Programme Delivery Excellence",
      description: "End to end delivery of programme with expert-led implementation and consistently high satisfaction ratings.",
      details: [
        "End to end delivery of programme",
        "Expert-led implementation with consistently high satisfaction ratings of 4.5/5 across all programmes"
      ],
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80"
    },
    {
      title: "HRD Grants Submission & Claims",
      description: "Specialized support for funding applications with a proven 90% success rate across client engagements.",
      details: [
        "EIS programmes"
      ],
      image: "https://images.unsplash.com/photo-1573166364524-d9dbfd8bbf83?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80"
    },
  ];

  return (
    <section id="programs" className="section-padding bg-edu-light-gray">
      <div className="container-custom mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-edu-blue mb-4">
            Tailored Services
          </h2>
          <p className="text-edu-gray text-lg max-w-3xl mx-auto">
            We deliver comprehensive solutions for organizations serving working adults. Our services span from strategic consulting to full implementation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-md transition-all hover:shadow-lg"
            >
              <div className="h-52 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-700"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-edu-blue mb-3">
                  {service.title}
                </h3>
                <p className="text-edu-gray mb-4">{service.description}</p>
                <ul className="list-disc pl-5 mb-4 text-edu-gray">
                  {service.details.map((detail, idx) => (
                    <li key={idx} className="mb-1">{detail}</li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-edu-gray mb-8 text-lg max-w-3xl mx-auto">
            Our proven track record demonstrates our commitment to delivering exceptional value for organizations and their working professional populations.
          </p>
        </div>

        <div className="mt-16 bg-gradient-to-r from-edu-blue to-edu-teal text-white p-8 md:p-12 rounded-2xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold mb-4">
                Transforming business performance through life-long learning
              </h3>
              <p className="mb-6 text-white/90">
                For corporate and global markets proven expertise.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button className="bg-white text-edu-blue hover:bg-white/90">
                  Contact Us
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 p-4 rounded-lg">
                <h4 className="font-semibold text-xl mb-1">Global Reach</h4>
                <p className="text-white/80 text-sm">Delivering innovative solutions across 8 countries and 12 diverse industries globally.</p>
              </div>
              <div className="bg-white/10 p-4 rounded-lg">
                <h4 className="font-semibold text-xl mb-1">Proven Results</h4>
                <p className="text-white/80 text-sm">Achieved 25% business growth success rate within 12 months.</p>
              </div>
              <div className="bg-white/10 p-4 rounded-lg text-center md:text-left col-span-2">
                <h4 className="font-semibold text-xl mb-1">Comprehensive Expertise</h4>
                <p className="text-white/80 text-sm">Specializing in strategy development, business growth, product integration, and project delivery.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Programs;
